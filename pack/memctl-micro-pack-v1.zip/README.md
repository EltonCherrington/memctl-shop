Micro Pack
Distilled starter: cheat-sheet.md + base/CLAUDE.md. Pairs with memctl (CLI).
